# E-Arsip Kantor — Versi Uji Coba Offline

Versi ini sengaja tidak memakai Firebase, internet, atau akun cloud. Semua data metadata disimpan di SQLite lokal dan lampiran disalin ke direktori privat aplikasi Android.

## Akun demo
- Admin: `admin` / `admin12345`
- Pegawai: `pegawai` / `pegawai12345`

Kata sandi disimpan sebagai hash SHA-256 di database lokal, bukan teks biasa. Akun demo hanya untuk pengujian. Jangan gunakan kredensial ini untuk pemakaian kantor sesungguhnya.

## Fitur tersedia
- Login lokal Admin dan Pegawai.
- Tambah/edit dokumen, kategori, nomor, tanggal, pengirim/penerima, catatan.
- Lampiran PDF, Word, Excel, JPG/PNG/WEBP disalin ke folder privat aplikasi agar tetap tersedia offline.
- Pencarian arsip.
- Hapus dokumen hanya untuk Admin.
- SQLite lokal.

## Jalankan proyek
Perlu komputer dengan Node.js LTS:
```bash
npm install
npx expo start
```
Buka lewat Expo Go atau emulator Android. Internet mungkin dibutuhkan saat pertama kali memasang dependensi Expo; setelah aplikasi terpasang, fitur arsip berjalan offline.

## Batasan uji coba
- Data hanya berada di satu perangkat; belum tersinkron antar-HP.
- Belum ada ekspor/impor backup, enkripsi file lampiran, ganti kata sandi dari aplikasi, atau pengelolaan akun pegawai melalui menu.
- Menghapus catatan arsip belum menghapus file lampiran fisik; jangan menganggap penghapusan sebagai pemusnahan aman.
- Hapus data aplikasi/uninstall dapat menghilangkan arsip lokal. Lakukan salinan cadangan sebelum uji dengan data penting.
- Versi ini untuk uji coba dengan dokumen contoh, bukan untuk menyimpan arsip rahasia atau dokumen resmi tanpa backup dan peninjauan keamanan.
